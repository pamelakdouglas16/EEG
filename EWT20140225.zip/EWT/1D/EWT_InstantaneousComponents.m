function Hilb = EWT_InstantaneousComponents(ewt,Fe)

%% First we compute the instantaneous amplitude and frequencies
Hilb=cell(length(ewt),4);
for i=1:length(ewt)
   ht=hilbert(ewt{i});
   Hilb{i}{1}=abs(ht);
   Hilb{i}{2}=unwrap(angle(ht));
   %Hilb{i}{2}=angle(ht);
   %Hilb{i}{3}=diff(Hilb{i}{2})*Fe;
   %Hilb{i}{3}=[Hilb{i}{3} ; Hilb{i}{3}(end)];
   Hilb{i}{3}=(Hilb{i}{2}(3:end)-Hilb{i}{2}(1:end-2))*Fe/2;
   Hilb{i}{3}=[Hilb{i}{3}(1) ; Hilb{i}{3} ; Hilb{i}{3}(end)];
   
   Hilb{i}{4}=IFcleaning(Hilb{i}{3});
   %if i==11
   figure;
   subplot(411);plot(Hilb{i}{1});
   subplot(412);plot(Hilb{i}{2});
   subplot(413);plot(Hilb{i}{3});
   subplot(414);plot(Hilb{i}{4});
   %end
end