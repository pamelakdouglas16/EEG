function PlotStats(L)

%==========================================================================
% function PlotStats(L)
%
% This function plots some statistical information about the set of minima
% curve lengths: L itself, the histogram of the lengths and the accumulated
% histogram of the lengths
%
% Inputs:
%   -L: the set of minima curve lengths
%
% Author: Jerome Gilles
% Institution: UCLA - Department of Mathematics
% Year: 2013
% Version: 2.0
% =========================================================================

histo=hist(L,max(L));
chisto=cumsum(histo/sum(histo));
figure;
subplot(131);plot(L,'+');title('Lengths');
subplot(132);plot(histo);title('Histogram');
subplot(133);plot(chisto);title('Accumulated histogram');