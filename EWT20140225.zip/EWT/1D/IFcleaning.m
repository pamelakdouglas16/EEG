function f=IFcleaning(f)

i=length(f);
if f(i)<0
    while (f(i)<0 && i>0)
        i=i-1;
    end
    for k=i+1:length(f)
       f(k)=f(i); 
    end
end

i=1;
if f(1)<0
    while (f(i)<0 && i<length(f))
           i=i+1;
    end
    for k=1:i-1
       f(k)=f(i); 
    end
end

while i<length(f)
   if f(i)>=0
       i=i+1;
   else
       p=i-1;
       while (f(i)<0 && i<length(f))
           i=i+1;
       end
       a=(f(i)-f(p))/(i-p);
       b=f(p)-a*p;
       for k=(p+1):i
          f(k)=a*k+b; 
       end
   end
end