This Matlab Toolbox permits to perform the 1D and 2D Empiricals transforms described in the papers:

- J.Gilles, "Empirical wavelet transform" to appear in IEEE Trans. Signal Processing, 2013.
Preprint available at ftp://ftp.math.ucla.edu/pub/camreport/cam13-33.pdf
- J.Gilles, G.Tran, S.Osher "2D Empirical transforms. Wavelets, Ridgelets and Curvelets Revisited", submitted in SIAM Journal on Imaging Sciences, 2013.
Preprint available at ftp://ftp.math.ucla.edu/pub/camreport/cam13-35.pdf

This toolbox is freely distributed and can be used without any charges for research purposes but I will appreciate if you cite the previous papers ;-)
If you want to use this code for commercial purposes, please contact me before.

For any questions, comments (if you find a bug please send me all information so I can fix it and update the toolbox) must be send to jegilles@math.ucla.edu

If you develop some new functionalities and want them included in this toolbox, just provide me the corresponding files and which credit I must add in this README file.


==========================================================
									NEEDED TOOLBOXES
==========================================================

If you want to run all functionalities, you need to have the following toolboxes properly installed on Matlab:

- Flandrin's EMD toolbox (needed in the 1D transform to perform the Hilbert transform and visualize the time-frequency plane) 
	available at http://perso.ens-lyon.fr/patrick.flandrin/emd.html
- Elad's Pseudo-Polar FFT toolbox (needed for the 2D transforms except the tensor based transform)
	available at http://www.cs.technion.ac.il/~elad/software/

==========================================================
										INSTALLATION
==========================================================

1- Add the path to all folders to your Matlab configuration
2- Go in the Boundaries/FTC and compile the file ftc_seg.c by using the command (on Matlab): mex ftc_seg.c
(this operation assume you have properly configure a C compiler on your Matlab!)

==========================================================
										ORGANIZATION
==========================================================
This toolbox is organized as follows:

EWT
 |
 |-1D 										: 1D EWT functions
 |-2D											: 2D EWT functions
 |	|-Curvelet 						: Empirical curvelet transform
 |  |-Littlewood-Paley 		: Empirical Littlewood-Paley wavelet transform
 |  |-Ridgelet 						: Empirical Ridgelet transform
 |  |-Tensor 							: Empirical Tensor wavelet transform
 |-Boundaries							: functions used to perform to Fourier supports
 |	|-FTC									: Fine to Coarse algorithm
 |  |-LocalMaxima					: Functions performing the detections based on local maxima and midway or localminima
 |  |-MorphoMath					: Functions performing the Morphological operator to preprocess the spectrum
 |  |-PowerLaw						: Function preprocessing the spectrum by removing its power law approximation
 |-Tests
 |	|-1D									: Functions to perform basic tests on several 1D signals
 |	|-2D									: Functions to perform basic tests of the several 2D transforms on different images

==========================================================
										UTILIZATION
==========================================================
The best way to learn how to use this toolbox is to look and play with the files named Test_xxxx on the subfolders of the Tests folder.
The provided test scripts are the ones used to generate the experiments presented in the two papers.
Some utlities are provided to visualize the transform outputs, the detected Fourier supports, ...
