%N=100; %number of initial intervals to find

%there are N intervals (so, N-1 boundaries not including {0,pi})
%disjoint, covering [0,pi] stored as a set of N-1 boundaries (b_1, ...,
%b_{N-1})

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%THIS WAS ALL FROM TEST_FUSION_ADAPT EXACTLY

%% Test of different Fourier boundaries detection strategies

%clear all
clear f ff funct params signal

%% User setup
% Choose the signal you want to analyze
% (sig1,sig2,sig3,sig4=ECG,sig5=seismic,lena,textures)
signal = 'sig3'; %'eeg' draws from the STIM file
params.channel = 118; %try comparing to 159 for an "irregular traditional"
params.SamplingRate = 250;
entropy_strategy='shannon';

params.globtrend = 'none';% Choose the wanted preprocessing (none,plaw,poly,morpho,tophat)
params.degree = 5; % degree for the polynomial interpolation

params.reg = 'none'; % regularization technique in preprocessing (none,gaussian,average,closing)
                                                   %NOTE: EWT_Boundaries_Detect, and Adaptive_Bounds as it was originally
                                                   %written, will not work on the closing function, since they define local
                                                   %minima as being "spikes". So on a closing function, no local minima at all
                                                   %will be found.
params.lengthFilter=5; %length of filter or structural element, a good one is 5
params.sigmaFilter=1.5; %standard deviation for the gaussian filter case

% Choose the wanted detection method (locmax,locmaxmin,ftc,adaptive,adaptivereg,closure,traditional)
params.detect = 'locmaxminf';
params.N = -1; % maximum number of band for the locmaxmin method %%JEROMES WAS ORIGINALLY 6
params.completion = 0;
params.log=0; % Perform the detection on the log spectrum instead the spectrum
params.InitBounds = [4 8 13 30 60];


%% Load signals
switch lower(signal)
    case 'sig1'
        load('sig1.mat');
        t=0:1/length(f):1-1/length(f);
    case 'sig2'
        load('sig2.mat');
        t=0:1/length(f):1-1/length(f);
    case 'sig3'
        load('sig3.mat');
        t=0:1/length(f):1-1/length(f);
    case 'sig4'
        load('sig4.mat');
        t=0:length(f)-1;
    case 'sig5'
        load('seismic.mat');
        f=f(10000:20000); %sub portion of the signal used in the paper
        t=0:length(f)-1;
    case 'lena'
        load lena
        fftim=fft(f');
        ff=abs(sum(abs(fftim),2)/size(fftim,2));
        fftim=ff;
    case 'textures'
        load('texture.mat');
        fftim=fft(f');
        phi=abs(sum(angle(fftim),2)/size(fftim,2));
        ff=abs(sum(abs(fftim),2)/size(fftim,2));
        [x,y]=pol2cart(phi,ff);
        f=real(ifft2(complex(x,y)));
        fftim=ff;
end

if (~strcmp(signal,'lena')) && (~strcmp(signal,'textures'))
    % We compute the Fourier transform of f
    ff=abs(fft(f));
    fftim=ff;
end

%% Initialize the set of boundaries by keeping all local minima on the spectrum
% We compute the Fourier transform of f
boundaries = EWT_Boundaries_Detect(ff(1:round(length(ff)/2)),params);
boundaries = boundaries*2*pi/length(ff);

%% Filtering
% We extend the signal by miroring to deal with the boundaries
l=round(length(f)/2);
f=[f(l-1:-1:1);f;f(end:-1:end-l+1)];
ff=fft(f);

% We build the corresponding filter bank
mfb=EWT_Meyer_FilterBank(boundaries,length(ff));
lmfb=length(mfb);
% We filter the signal to extract each subband and compute entropy per band
ewt=cell(lmfb,1);
l2norm=zeros(lmfb,1);
for k=1:lmfb
    ewt{k}=real(ifft(conj(mfb{k}).*ff));
    ewt{k}=ewt{k}(l:end-l);
    l2norm(k)=norm(ewt{k},1);
end
% Compute total entropy
%Tent=wentropy(l2norm,entropy_strategy)
l2norm

stop=0;
%Show_EWT(ewt);
Show_EWT_Boundaries(fftim,boundaries,1,-1);
%Brec=iEWT1D(ewt,mfb);
%B=boundaries;
%BMFB=mfb;
%BEWT=ewt;

disp('========================================================');

%while (stop~=1)
% Test consecutive merged filters
Mmfb=cell(lmfb-1,1);
Mewt=cell(lmfb-1,1);
Ml2norm=zeros(lmfb-1,1);
TMent=zeros(lmfb-1,1);
for m=1:lmfb-1
   % build merged filters
   Mmfb{m}=sqrt(mfb{m}.^2+mfb{m+1}.^2);
   % filter the signal
   Mewt{m}=real(ifft(conj(Mmfb{m}).*ff));
   Mewt{m}=Mewt{m}(l:end-l);
   % compute corresponding entropy
   Ml2norm(m)=norm(Mewt{m},1);
%    TMent(m)=wentropy(Ml2norm(m),entropy_strategy);
%    for k=1:lmfb-2
%       TMent(m)=TMent(m)+wentropy(l2norm(mod(m+k,lmfb)+1),entropy_strategy);
%    end
end

Ml2norm

% % find the merging which minimum entropy
% [minent,indent]=min(TMent);
% % test if the merged entropy is smaller than the original one
% if Tent<minent
%     stop=1;
% else % we keep the new partition
%     if indent~=lmfb-1
%         mfb{indent}=Mmfb{indent};
%         mfb(indent+1)=[];
%         ewt{indent}=Mewt{indent};
%         ewt(indent+1)=[];
%         boundaries=[boundaries(1:indent-1) boundaries(indent+1:end)];
%         l2norm=[l2norm(1:indent-1) ; Ml2norm(indent) ; l2norm(indent+2:end)];
%     else
%         mfb{indent}=Mmfb{indent};
%         mfb(end)=[];
%         ewt{indent}=Mewt{indent};
%         ewt(end)=[];
%         boundaries=boundaries(1:end-1);
%         l2norm=[l2norm(1:end-1) ; Ml2norm(indent)];
%         
%     end
%     Tent=TMent(indent)
%     lmfb=lmfb-1;
%end
%Show_EWT(ewt);
Show_EWT_Boundaries(fftim,boundaries,1,-1);
%end
%rec=iEWT1D(ewt,mfb);

%% We perform the empirical transform and its inverse
% compute the EWT (and get the corresponding filter bank and list of 
% boundaries)
%[ewt,mfb,boundaries,BO,BN]=EWT1D(f,Nbscales,detect,0,params);
% [ewt,mfb,boundaries]=EWT1D(f,params);

%[ewt,mfb,boundaries,presig]=EWT1D_Adapt(f,params);
% disp('Boundaries as a result of EWT1D_Adapt are: ');
% [ewt,mfb,boundaries]=EWT1D(f,params); %% JEROME ADDON
% %[ewt,mfb,boundaries,~]=EWT1D_Adapt(f,params);
% 
% %THIS WAS ALL FROM TEST_FUSION_ADAPT EXACTLY
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% entropy_strategy='shannon';
% %numIntervals=params.N;
% numIntervals=length(boundaries)-1; %% JEROME ADDON
% minIntervals=2; %could also set upper bound to  params.N-2 to get 1 bound
% %signal_length=3000;
% signal_length=length(f); %% JEROME ADDON
% flag=0;

%boundaries=round(boundaries.*(signal_length/(2*pi)));%% THIS IS AD HOC

%convert decomposed signal values from cells to a readable matrix
%ewt_coeff=zeros(signal_length,length(ewt)); %% JEROME ADDON
%ewt_coeff=zeros(signal_length,params.N);
%for i=1:params.N
% for i=1:length(ewt) %% JEROME ADDON
%     ewt_coeff(:,i)=ewt{i};
%     
%     %%TRY NORMALIZING EACH COMPOSITION SIGNAL-- THIS IS EXPERIMENTAL 10/10
%     %ewt_coeff(:,i)=ewt_coeff(:,i)./norm(ewt_coeff(:,i)); %L2 norm %this will also ensure that all shannon entropy values are nonnegative as in the CMU paper
% end

%while(flag~=-1 && flag < params.N-minIntervals)
% while(flag~=-1 && flag < length(ewt)-minIntervals) %% JEROME ADDON
%     flag;
%     ent_all=0;
%     %find the entropy of the original partition (initially flag=0 given by
%     %EWT_Boundaries_Adapt). This should consider the maximal number of bands
%     %for this interval.
%     %for i=1:params.N-flag
%     for i=1:length(ewt)-flag  %% JEROME ADDON
%         format long
%         ent_all=ent_all+wentropy(ewt_coeff(:,i),entropy_strategy);
%     end
%     
%     ent_compare=zeros(params.N-1-flag);
%     %for i=1:params.N-1-flag
%     for i=1:length(ewt)-1-flag %refers to the act of deleting the ith boundary
%         %select those bands and corresponding wavelet coefficients in a L1O strategy, leaving out the ith boundary
%         temp_ewt=[ewt_coeff(:,1:i-1),ewt_coeff(:,end:-1:i+2)]; %each column of ewt_coeff corresponds to a single spectral band
%         compare=0;
%         %sum up that L1O iteration's entropy over all the intervals
%         stop=size(temp_ewt);
%         stop=stop(2);
%         %add the preserved N-2-flag intervals
%         %for j=1:params.N-2-flag
%         for j=1:length(ewt)-2-flag %% JEROME ADDON
%             compare=compare+wentropy(temp_ewt(:,j),entropy_strategy);
%         end
%         %add the entropy of the two merged intervals
%         ent_compare(i)=compare+wentropy(ewt_coeff(:,i)+ewt_coeff(:,i+1),entropy_strategy);
%     end
%     
%     %find which one of the N-1 L1O options yields the lowest, (AKA the highest
%     %in absolute value) and therefore most "competitive" entropy value.
%     [ent_compare_sort, ind_remove]=min(ent_compare);
%     
%     %choose the boundary with the most competitive entropy value
%     %this should be boundary #ind_remove
%     if ent_compare_sort<ent_all
%         
%         %update the list of optimal boundaries, to NOT include boundary
%         %#ind_remove if it behooves the final entropy value
%         boundaries=[boundaries(1:ind_remove-1), boundaries(ind_remove+1:params.N-1-flag)];
%         
%         %update the list of intervals, summing the wavelet coefficients of
%         %the two intervals being merged, and therefore adding them in every
%         %iteration past this one.
%         ewt_coeff=[ewt_coeff(:,1:ind_remove-1), ewt_coeff(:,ind_remove)+ewt_coeff(:,ind_remove+1), ewt_coeff(:,ind_remove+2:params.N-flag)]; 
%         
%         %update the current (thus far, optimal) entropy value for the
%         %partition
%         ent_all=ent_compare_sort;
%         
%         %update the flag
%         flag=flag+1;
%     
%     %however if none of the L1O options is "better" than the original
%     %partition from the top of this while loop step, then keep the current
%     %partition and terminate the algorithm.
%     else if ent_compare_sort>=ent_all
%             flag=-1;
%          end
%     end
% end

%disp('Boundaries as a result of entropy are: ', boundaries);
%Show_EWT_Boundaries(abs(sum(abs(fftim),2)/size(fftim,2)),boundaries,1,-1);

% figure
% plot(abs(fft(f)))
% hold on
% axis([1 1500 0 4000])
% for k=1:length(boundaries)
%     line([boundaries(k) boundaries(k)], [0 4000],'LineWidth',1,'LineStyle','--','Color',[0 1 1])
%     hold on
% end
% title(gca,'The boundaries were chosen based on the INDIVIDUAL.')
% xlabel(gca,'The red boundaries should not necessarily correspond to any global minima of this function.')
    