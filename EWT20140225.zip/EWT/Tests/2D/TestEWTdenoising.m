clear all;
load lena.mat;load Nlena.mat;
%load texture.mat;load Ntexture.mat;
%load barb.mat;

delta=1;
deltamax=2.5;
dd=0.1;


%% wavelet global parameters
N=9; %number of scales
typewavelet='EWTcurvelet';

% Choose the wanted preprocessing (none,plaw,poly,morpho,tophat)
params.globtrend = 'morpho';
params.degree=5; % degree for the polynomial interpolation


% Choose the wanted detection method (locmax,locmaxmin,ftc)
params.method = 'locmaxmin';
params.N = N; % maximum number of band for the locmaxmin method
params.completion=0;

% Perform the detection on the log spectrum instead the spectrum
params.log=1;

% Type of curvelet transform (1=scale and radius independent, 2=angles per
% scales)
params.option=2;

% Choose the wanted detection method for the angles (locmax,locmaxmin)
params.curvmethod='locmaxmin';
params.curvN=3;

% Choose the wanted preprocessing for the angles (none,plaw,poly,morpho,tophat)
params.curvpreproc='tophat';
params.curvdegree=4;



%% ====================================================
%thresholding parameters
typeseuillage='soft';
thresh=sqrt(2*log(size(f,1)*size(f,2))); %Donoho's threshold


%Add Gaussian noise
%sigma=1; %noise std
%noisy = GWNoisy2(f,sigma);

%opsnr=norm(myrenorm(f)-myrenorm(noisy),'fro');
Ddelta(1)=0;
psnr(1)=mypsnr(f,noisy,255);
myssim(1)=ssim(myrenorm(f),myrenorm(noisy));
imdenoised{1}=noisy;
fprintf(1,'n=%d | delta=%f | psnr=%f | ssim=%f\n',1,Ddelta(1),psnr(1),myssim(1));

n=2;
while delta<=deltamax

switch typewavelet
    case 'wavelet'
        %perform classic wavelet transform
        qmf = MakeONFilter('Symmlet',4);
        L=8-N;
        wcoef = FWT2_PO(noisy,L,qmf);

        switch typeseuillage
            case 'soft' 
                %soft thresholding
                twcoef=SoftThresh(wcoef,delta*thresh);
            case 'hard'
                %hard thresholding
                twcoef=HardThresh(wcoef,delta*thresh);
        end
        twcoef(1:2^L,1:2^L)=wcoef(1:2^L,1:2^L);

        %reconstruction
        denoised = IWT2_PO(twcoef,L,qmf);
    case 'curvelet'
        ccoef = fdct_wrapping(noisy,1,1,N);
        dcurv=cell(size(ccoef));
        dcurv{1}=cell(1);
        dcurv{1}{1}=ccoef{1}{1};
        for s=2:size(ccoef,2)
            for a=1:size(ccoef{s},2)
                switch typeseuillage
                    case 'soft' 
                        %soft thresholding
                        dcurv{s}{a}=SoftThresh(ccoef{s}{a},delta*thresh);
                    case 'hard'
                        %hard thresholding
                        dcurv{s}{a}=HardThresh(ccoef{s}{a},delta*thresh);
                end
            end
        end
        
        %reconstruction
        denoised=ifdct_wrapping(dcurv,1,size(noisy,1),size(noisy,2));
    case 'ridgelet'
        %perform classic ridgelet transform
        L=size(noisy,2)/2^N+1;
        wcoef = ridgelet(noisy,N);

        switch typeseuillage
            case 'soft' 
                %soft thresholding
                twcoef=SoftThresh(wcoef,delta*thresh);
            case 'hard'
                %hard thresholding
                twcoef=HardThresh(wcoef,delta*thresh);
        end
        twcoef(:,1:L)=wcoef(:,1:L);

        %reconstruction
        denoised = iridgelet(twcoef,N);
    case 'EWTtensor'
        %perform EWT 2D Tensor
        [ewtc,mfbR,mfbC]=EWT2D_Tensor(noisy,params);
        dewtc=cell(size(ewtc));
        for l=1:size(ewtc,1)
            for c=1:size(ewtc,2)
                switch typeseuillage
                    case 'soft' 
                        %soft thresholding
                        dewtc{l}{c}=SoftThresh(ewtc{l}{c},delta*thresh);
                    case 'hard'
                        %hard thresholding
                        dewtc{l}{c}=HardThresh(ewtc{l}{c},delta*thresh);
                end
                dewtc{1}{1}=ewtc{1}{1};
            end
        end
        denoised=iEWT2D_Tensor(dewtc,mfbR,mfbC);
    case 'EWTridgelet'
        %perform EWT 2D Tensor
        [ewtc,mfb]=EWT2D_Ridgelet(noisy,params);
        dewtc=cell(size(ewtc));
        dewtc{1}=ewtc{1};
        for l=2:size(ewtc,1)
                switch typeseuillage
                    case 'soft' 
                        %soft thresholding
                        dewtc{l}=SoftThresh(ewtc{l},delta*thresh);
                    case 'hard'
                        %hard thresholding
                        dewtc{l}=HardThresh(ewtc{l},delta*thresh);
                end
        end
        denoised=iEWT2D_Ridgelet(dewtc,mfb);
     case 'EWTlp'
        %perform EWT 2D Tensor
        [ewtc,mfb]=EWT2D_LittlewoodPaley(noisy,params);
        dewtc=cell(size(ewtc));
        for l=1:size(ewtc,1)
                switch typeseuillage
                    case 'soft' 
                        %soft thresholding
                        dewtc{l}=SoftThresh(ewtc{l},delta*thresh);
                    case 'hard'
                        %hard thresholding
                        dewtc{l}=HardThresh(ewtc{l},delta*thresh);
                end
                dewtc{1}=ewtc{1};
        end
        denoised=iEWT2D_LittlewoodPaley(dewtc,mfb);
    case 'EWTcurvelet'
        %perform EWT 2D Tensor
        [ewtc,mfb]=EWT2D_Curvelet(noisy,params);
        dewtc=cell(size(ewtc));
        dewtc{1}=ewtc{1};
        for l=2:size(ewtc,1)
            dewtc{l}=cell(size(ewtc{l}));
            for c=1:size(ewtc{l},1)
                switch typeseuillage
                    case 'soft' 
                        %soft thresholding
                        dewtc{l}{c}=SoftThresh(ewtc{l}{c},delta*thresh);
                    case 'hard'
                        %hard thresholding
                        dewtc{l}{c}=HardThresh(ewtc{l}{c},delta*thresh);
                end
            end
        end
        denoised=iEWT2D_Curvelet(dewtc,mfb);
end

psnr(n)=mypsnr(f,denoised,255);
myssim(n)=ssim(myrenorm(f),myrenorm(denoised));
Ddelta(n)=delta;
imdenoised{n}=denoised;

fprintf(1,'n=%d | delta=%f | psnr=%f | ssim=%f\n',n,Ddelta(n),psnr(n),myssim(n));

n=n+1;
%delta=delta+0.1;
delta=delta+dd;
%dpsnr=norm(myrenorm(f)-myrenorm(denoised),'fro');
end


%fprintf(1,'N=%d | %s | sigma=%f | delta=%f | Noisy image PSNR=%f | Denoised image PSNR=%f\n',N,typeseuillage,sigma,delta,opsnr,dpsnr);

%plots
% subplot(131);imshow(myrenorm(f),[]);title('Original');
% subplot(132);imshow(myrenorm(noisy),[]);title('Noisy');
% subplot(133);imshow(myrenorm(denoised),[]);title('Denoised');