function [ f ] = LoadEEG( channel )
    load data_STIM2
    f=STIM;
    f=f(channel,:,81);
    f=f';
end

