/* This file is a modified version of Julie Delon's megawave code to perform
  the FTC histogram segmentation. The modifications consists in adding and 
  simplifying some megawave kernel function and removing some useless part
  of the original FTC code.
*/

/*--------------------------- Commande MegaWave -----------------------------*/
/* mwcommand
  name = {ftc_seg};
  version = {"1.0"};
  author = {"Julie Delon"};
  function = {"histogram fine to coarse segmentation"};
*/
/*-- MegaWave - Copyright (C) 1994 Jacques Froment. All Rights Reserved. --*/

/*2005 feb : output changed, bounds of the whole interval are excluded*/
/*2005 april :  improvement in pooling_adjacent_violators  (Pascal Monasse)*/
/*2005 june :  the modes are merged by order of meaningfullness, starting with the merging which follows "the best" the unimodal hypothesis*/
/*2013 april: modifications for Matlab mex file embedding (Jerome Gilles)*/

#include "mex.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>

#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

/*=============================================*/
/* HERE ARE THE USEFUL FUNCTIONS FROM MEGAWAVE */
/*=============================================*/
/* double Point Signal */
typedef struct fsignal {
  int size;        /* Number of samples */
  double *values;   /* The samples */
} *Fsignal;


/* double List */
typedef struct flist {

  int max_size;
  int size;          /* size (number of elements) */
  double *values;     /* values = size * dim array
			  nth element = values[n*dim+i], i=0..dim-1 */
} *Flist;


/* Change the size of the allocated array */
/* May define the struct if not defined */
/* So you have to call it with signal = mw_change_fsignal(signal,...) */
/* creates a new fsignal structure */

Fsignal mw_new_fsignal() {
  Fsignal signal;

  if(!(signal = (Fsignal) (malloc(sizeof(struct fsignal))))) {
      mexPrintf("[mw_new_fsignal] Not enough memory\n");
      return(NULL);
  }

  signal->size = 0;
  signal->values = NULL;

  return (signal);
}

/* allocates the values array for N samples */ 

Fsignal mw_alloc_fsignal(Fsignal signal,int N) {
  int mem_size;

  if (signal == NULL) {
      mexPrintf("[mw_alloc_fsignal] cannot alloc array : fsignal structure is NULL\n");
      return(NULL);
  }

  mem_size =  N*sizeof(double);
  if (mem_size <= 0) {
      mexPrintf("[mw_alloc_fsignal] Attempts to alloc a fsignal with null size\n");
      return(NULL);
  }

  if (signal->values != NULL) {
      mexPrintf("[mw_alloc_fsignal] Attempts to alloc a fsignal which is already allocated\n");
      return(NULL);
  }

  signal->values = (double *) malloc(mem_size);
  if (signal->values == NULL) {
      signal->size = 0;
      mexPrintf("[mw_alloc_fsignal] Not enough memory\n");
      return(signal);
  } else {
      signal->size=N;
      return(signal);
  }
}

/* desallocate the array in the fsignal structure and the structure itself */

void mw_delete_fsignal(Fsignal signal) {
  if (signal == NULL) {
      mexPrintf("[mw_delete_fsignal] cannot delete : fsignal structure is NULL\n");
      return;
  }

  if (signal->values != NULL) free(signal->values);
  signal->values = NULL;
  free(signal);
  signal=NULL;
}

/* Change the size of the allocated array */
/* May define the struct if not defined */
/* So you have to call it with signal = mw_change_fsignal(signal,...) */
Fsignal mw_change_fsignal(Fsignal signal,int N) {
  int mem_size;
  
  if (signal == NULL) signal = mw_new_fsignal();
  if (signal == NULL) return(NULL);

  if (N > signal->size) {
    if (signal->values != NULL) {
	  free(signal->values);
	  signal->values = NULL;
	}
    if (mw_alloc_fsignal(signal,N) == NULL) {
	  mw_delete_fsignal(signal);
	  return(NULL);
	}
  }
  else signal->size = N;

  return(signal);
}

/* Copy a fsignal into another fsignal */
void mw_copy_fsignal(Fsignal in, Fsignal out) {
  if ((!in) || (!out) || (!in->values) || (!out->values) || (in->size != out->size)) {
      mexPrintf("[mw_copy_fsignal] NULL input or output signal or signals of different sizes !\n");
      return;
  }

  memcpy(out->values, in->values, sizeof(double) * in->size);
}


/* extract a subpart of a signal */
Fsignal sextract(int a,int b,Fsignal in) {
  Fsignal out=0;
  int i;
  
  if(a>b) mexPrintf("a must be smaller than b!\n"); 
  out=mw_change_fsignal(out,b-a+1);

  for(i=0;i<out->size;i++) out->values[i]=in->values[i+a];
  
  return(out);
}

/* Create a new flist structure */
Flist mw_new_flist() {
  Flist l;

  if(!(l = (Flist) (malloc(sizeof(struct flist))))) {
    mexPrintf("[mw_new_flist] Not enough memory\n");
    return(NULL);
  }
  l->size = l->max_size = 0;
  l->values = NULL;

  return (l);
}


/* (Re)allocate the values[] array in a flist structure */
Flist mw_realloc_flist(Flist l,int n) {
  double *ptr;

  if (!l) {
    mexPrintf("[mw_realloc_flist] flist structure is NULL\n");
    return(NULL);
  }

  if (n<l->size) mexPrintf("[mw_realloc_flist] data may have been lost\n");
  ptr = (double *)realloc(l->values,n*sizeof(double));
  if (!ptr && n!=0) {
      mexPrintf("[mw_realloc_flist] Not enough memory\n");
      if (l->values) free(l->values);
      free(l);
      return(NULL);
  }
  l->values = ptr;
  l->max_size = n;
  return(l);
}


/* Configure and (re)allocate a flist structure */ 

Flist mw_change_flist(Flist l,int max_size,int size) {
  int n;

  if (!l) {
    l = mw_new_flist();
    if (!l) return(NULL);
  }

  l->size = size;
  if (size<0 || size>max_size) {
    mexPrintf("[mw_change_flist] Inconsistant size\n");
    return(l);
  }
    
  /* (re)allocate values[] */
  if (max_size>l->max_size) 
    return(mw_realloc_flist(l,max_size));

  return(l);
}

/* Delete a flist structure */ 

void mw_delete_flist(l)
     Flist l;
{
  if (!l) {
    mexPrintf("[mw_delete_flist] flist structure is NULL\n");
    return;
  }
  if (l->values) free(l->values); 
  free(l);
}


/*======================================================*/
/*  HERE START THE CODE FOR THE HISTOGRAM SEGMENTATION  */
/*======================================================*/

/* Relative entropy fonction */
double entrop(double x,double y) {
  if (x==0.0) return (-(double) log10(1-y));
  else  if (x==1.0) return (-(double) log10(y));
  else return (double) (x*log10(x/y)+(1.0-x)*log10((1.0-x)/(1.0-y)));
}



/*INCREASING OR DECREASING GRENANDER ESTIMATOR OF THE HISTOGRAM IN*/
Fsignal pooling_adjacent_violators(char *c,Fsignal in) {
  double som;
  Fsignal dec=0;
  int size,i,j,k;
  
  size=in->size;
  dec=mw_change_fsignal(dec,size);
  

  if (!c) {/*decreasing hypothesis*/ 
    dec->values[0]=in->values[0]; 
    for(i=1;i<size;i++) {
        dec->values[i]=in->values[i];
        som=dec->values[i];
        for(j=i-1;j>=-1;j--)  { 
            if(j==-1 || (dec->values[j]*(i-j) >=som)) {
                som/=(double)(i-j);
                for(k=j+1;k<=i;k++) dec->values[k]=som;
                break;
            }
            som+=dec->values[j];
        }	
    }
  } else {         /*increasing hypothesis*/
    dec->values[size-1]=in->values[size-1];
    for(i=size-2;i>=0;i--) {
        dec->values[i]=in->values[i];      
    	som=dec->values[i];
        for(j=i+1;j<=size;j++)  {
            if(j==size || (dec->values[j]*(j-i) >=som)) {
                som/=(double)(j-i);
                for(k=i;k<=j-1;k++) dec->values[k]=som;
                break;
            }
            som+=dec->values[j];
        }
    }
  }

  return dec;
}


/*Compute the max entropy of the histogram in_{|[a,b]} for the increasing or decreasing hypothesis */
/*c=1 for the increasing hypothesis, 0 for the decreasing one*/
double max_entropy(char *c,Fsignal in,int a,int b, double eps) {
  Fsignal extrait=0,decrois=0; 
  double seuil, H, r, p, max_entrop,N;
  int i,j,L;
  
  extrait=(Fsignal)sextract(a,b,in);
  decrois=(Fsignal)pooling_adjacent_violators(c,extrait);
  L=extrait->size;
  /* integrate signals */
  for (i=1;i<L;i++) extrait->values[i]+=extrait->values[i-1];
  for (i=1;i<L;i++) decrois->values[i]+=decrois->values[i-1];
  /*meaningfullness threshold*/
  N=extrait->values[L-1];
  seuil=log10((double)(L*(L+1)/2))/N+eps; 
  /*search the most meaningfull segment (gap or mode)*/
  max_entrop=0.;
  for(i=0;i<L;i++) {
    for(j=i;j<L;j++) {
      if(i==0) r=extrait->values[j];
      else	r=extrait->values[j]-extrait->values[i-1];
      r=r/N;
      if(i==0) p=decrois->values[j];
      else	p=decrois->values[j]-decrois->values[i-1];
      p=p/N;
      H=entrop(r,p);
      if(H>max_entrop) {
          max_entrop=H;
      }
    }
  }
  max_entrop=(max_entrop-seuil)*N;
  
  mw_delete_fsignal(extrait);
  mw_delete_fsignal(decrois);
  extrait=0;
  decrois=0;
  return max_entrop;
}


/***************************************/
/*****************MAIN******************/
/***************************************/
Flist ftc_seg(double eps,Fsignal in) {
  Flist out=0;
  int i,j,imin,size,n,m,M,iter,a,b;
  Flist list=0, max_entrop=0;
  double min_max_entrop, H;
  char *c;

  size=in->size;
  out=mw_change_flist(out,size,0);
  list=mw_change_flist(NULL,size,0);  /*ordered list of minima and maxima*/

  mexPrintf("Alloc \n");
  
  /*FIRST SEGMENTATION, the list 'list' is filled with all minima and maxima (min,max,min,max,etc...). 
   The list always starts and ends with a minimum.*/
  if (in->values[0]<in->values[1]) {
      list->values[0]=0.;
      list->size++;
  } else if(in->values[1]<in->values[0]) {
      list->values[0]=-1.;
      list->values[1]=0.; 
      list->size+=2;
  } else {
      for(j=1;(j<size)&&(in->values[j]==in->values[0]);j++) {}
      if (j==size) {
          list->values[0]=0.;
          list->size++;
      } else if(in->values[j]>in->values[0]) { /*case of a constant histogram*/
          list->values[0]=0.; 
          list->size++;
      } else {
          list->values[0]=-1.;
          list->values[1]=0.; 
          list->size+=2;
      }
  }
mexPrintf("First Seg P1 \n");
  for(i=1;i<size-1;i++) {
      /*strict minimum*/
      if((in->values[i]<in->values[i-1])&&(in->values[i]<in->values[i+1])) {
          list->values[list->size]=(double)i; 
          list->size++;
      } 
      
      /*large minimum*/
      if((in->values[i]<in->values[i-1])&&(in->values[i]==in->values[i+1])) {
          for(j=i+1;(j<size)&&(in->values[j]==in->values[i]);j++) {} 
          if (j==size) {
              list->values[list->size]=(double)size-1; 
              list->size++;
          } else if (in->values[j]>in->values[i]) {
              list->values[list->size]=0.5*(i+j-1); 
              list->size++;
          }
          i=j-1;
      }
      
      /*strict maximum*/
      if((in->values[i]>in->values[i-1])&&(in->values[i]>in->values[i+1])) {
          list->values[list->size]=(double)i; 
          list->size++;
      } 
      
      /*large maximum*/
      if((in->values[i]>in->values[i-1])&&(in->values[i]==in->values[i+1])) {
          for(j=i+1;(j<size)&&(in->values[j]==in->values[i]);j++) {}
          if(j==size) {
              list->values[list->size]=(double)size-1; 
              list->size++;
              list->values[list->size]=(double)size; 
              list->size++;
          } else if(in->values[j]<in->values[i]) {
              list->values[list->size]=0.5*(i+j-1); 
              list->size++;
          }
          i=j-1;
      }
  }
mexPrintf("First Seg P2 \n");
  if (in->values[size-1]<in->values[size-2]) {
      list->values[list->size]=(double)size-1; 
      list->size++;
  } else if (in->values[size-1]>in->values[size-2]) {
      list->values[list->size]=(double)size-1; 
      list->size++;list->values[list->size]=(double)size; 
      list->size++;
  }
mexPrintf("First Seg P3 \n");
  /*FILL THE LIST OF MAX ENTROPIES: the merging of two contiguous modes [a,b] and [b,c] can be done in two ways, either by using the maximum M1 on [a,b] and by testing the decreasing hypothesis on [M1,c], or by using the maximum M2 on [b,c] and by testing the increasing hypothesis on [a,M2]. For each configuration, we compute the entropy of the worst interval against the considered hypothesis.*/
  
  if(list->size<4) {
    mexPrintf("unimodal histogram ! \n"); 
    mw_delete_flist(list);
    list=NULL;
    return(out);
  }
  
  max_entrop=mw_change_flist(NULL,list->size-3,list->size-3);
  mexPrintf("Max entropies \n");
  for(i=0;i<list->size-3;i++) {
      if(i%2==0) { /* minimum at i -> configuration (max at i+1, min at i+2) in 'list' */
            m=(int)round(list->values[i]); /*minimum at i */
            M=(int)round(list->values[i+3]); /*maximum at i+3 */
            
            if (m!=-1) max_entrop->values[i]=max_entropy((char *)1,in,m,M,eps);
            else max_entrop->values[i]=max_entropy((char *)1,in,0,M,eps); 
      } else { /* maximum at i -> configuration (min at i+1, max at i+2)*/
            M=(int)round(list->values[i]); /*maximum at i */
            m=(int)round(list->values[i+3]); /*minimum at i+3 */
            
            if (m!=size) max_entrop->values[i]=max_entropy(NULL,in,M,m,eps);
            else max_entrop->values[i]=max_entropy(NULL,in,M,size-1,eps); 
      }
  }
  mexPrintf("end max entropies \n");
  /************************/
  /*  MERGING OF MODES    */
  /************************/
  /*Look for the "easiest" merging of two intervals*/
  min_max_entrop=max_entrop->values[0];
  imin=0;
  for(i=0;i<max_entrop->size;i++) {
      H=max_entrop->values[i];
      if(min_max_entrop>H) {
          min_max_entrop=H; 
          imin=i;
      }
  }
  mexPrintf("Merging P1 \n");
  while((min_max_entrop<0)&&(max_entrop->size>0)) {
      for(j=imin;j<max_entrop->size-2;j++) max_entrop->values[j]=max_entrop->values[j+2];
      for(j=imin;j<list->size-3;j++) list->values[j+1]=list->values[j+3];
      max_entrop->size-=2;
      list->size-=2;
            
      /*update of max_entrop*/
      for(i=MAX(imin-2,0);i<=imin;i++) {
          if(i%2==0) {
              m=(int)round(list->values[i]);  /*minimum at i */
              M=(int)round(list->values[i+3]);  /*maximum at i+3 */
              if (m!=-1) max_entrop->values[i]=max_entropy((char *)1,in,m,M,eps);
              else max_entrop->values[i]=max_entropy((char *)1,in,0,M,eps); 
	      } else {  /*configuration (min at i+1, max at i+2)*/
              M=(int)round(list->values[i]); /*maximum at i */
              m=(int)round(list->values[i+3]); /*minimum at i+3 */
              if (m!=size) max_entrop->values[i]=max_entropy(NULL,in,M,m,eps);
              else max_entrop->values[i]=max_entropy(NULL,in,M,size-1,eps); 
          }
      }
      
      min_max_entrop=max_entrop->values[0];
      imin=0;
      for(i=0;i<max_entrop->size;i++) {
          H=max_entrop->values[i];
          if(min_max_entrop>H) {
              min_max_entrop=H; 
              imin=i;
          }
      } 
      /*mexPrintf("min_max_entrop = %f (%d)\n",min_max_entrop,max_entrop->size);*/
      /*mexPrintf(".");*/
  }
mexPrintf("Merging P2 \n");
 /********/
 /*OUTPUT : list of all remaining minima without the bounds 0 and L-1*/
 /********/

  for(i=2;i<list->size-2;i++) {
      if((i%2==0)) {
          out->values[out->size]=list->values[i]+0.5;
          out->size++;
      }
  }
mexPrintf("Cleaning \n");
  mw_delete_flist(list);
  list=NULL;
  mexPrintf("Free \n");
  return(out);
}
     
/* the gateway function */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    
    double *f = mxGetPr(prhs[0]);
    int size = mxGetM(prhs[0]);
    double *u = mxGetPr(plhs[0]);
    Fsignal histo = 0;
    int i,nb;
    Flist bornes = 0;
    
    /*double eps = 0;*/
    
    /* cast the vector in the Gmg_Histogramme structure */
    histo = mw_change_fsignal(NULL,size);
    for (i=0;i<size;i++) {
        histo->values[i] = (double)f[i];
    }
    
    /*  call the C subroutine */
    bornes = ftc_seg(0,histo);
    
    if ((bornes->values == NULL) || (bornes->size == 0)) {
        plhs[0] = mxCreateDoubleMatrix(2, 1, mxREAL);
        u[0]=0;
        u[1]=size;
    } else {
        plhs[0] = mxCreateDoubleMatrix(bornes->size, 1, mxREAL);
        for (i=0;i<bornes->size;i++) {
            u[i] = bornes->values[i];
        }
    }
    mw_delete_fsignal(histo);
    mw_delete_flist(bornes);
    histo=0;
    bornes=0;
}